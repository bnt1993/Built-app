import tempfile
import unittest
from pathlib import Path

from app import collision_free_path, collapse_nested, file_size, is_within, valid_new_name


class FileOperationsTest(unittest.TestCase):
    def test_valid_names(self):
        self.assertTrue(valid_new_name('Báo cáo 2026.xlsx'))
        self.assertFalse(valid_new_name(''))
        self.assertFalse(valid_new_name('a/b'))
        self.assertFalse(valid_new_name('../secrets'))
        self.assertFalse(valid_new_name(' file '))

    def test_collision_does_not_overwrite_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp) / 'report.xlsx'
            base.write_text('do not overwrite')
            self.assertEqual(collision_free_path(base).name, 'report - bản sao.xlsx')
            (Path(tmp) / 'report - bản sao.xlsx').touch()
            self.assertEqual(collision_free_path(base).name, 'report - bản sao (2).xlsx')
            self.assertEqual(base.read_text(), 'do not overwrite')

    def test_collision_directory(self):
        with tempfile.TemporaryDirectory() as tmp:
            directory = Path(tmp) / 'archive.2026'
            directory.mkdir()
            self.assertEqual(collision_free_path(directory).name, 'archive.2026 - bản sao')

    def test_nested_paths(self):
        with tempfile.TemporaryDirectory() as tmp:
            parent = Path(tmp) / 'parent'
            child = parent / 'child'
            child.mkdir(parents=True)
            self.assertTrue(is_within(child, parent))
            self.assertFalse(is_within(parent, child))
            self.assertEqual(collapse_nested([str(parent), str(child), str(parent)]), [str(parent)])

    def test_file_size(self):
        self.assertEqual(file_size(None), '—')
        self.assertEqual(file_size(0), '0 B')
        self.assertEqual(file_size(2048), '2.0 KB')


if __name__ == '__main__':
    unittest.main()

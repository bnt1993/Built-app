"""Run under xvfb-run on Linux or on desktop Windows for a UI sanity check."""
import sys
import tempfile
import time
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app import FileHub

with tempfile.TemporaryDirectory() as temp:
    folder = Path(temp)
    for i in range(5):
        (folder / f"file-{i}.txt").write_text("hello", encoding="utf-8")
    (folder / "folder-a").mkdir()
    app = FileHub()
    app.navigate(temp)
    deadline = time.time() + 5
    while time.time() < deadline:
        app.update()
        if len(app.items) == 6:
            break
        time.sleep(.04)
    assert len(app.items) == 6, f"initial scan failed: {len(app.items)}"
    app.search_query.set('file-1')
    deadline = time.time() + 5
    while time.time() < deadline:
        app.update()
        if len(app.items) == 1 and 'file-1.txt' in next(iter(app.items)):
            break
        time.sleep(.05)
    assert len(app.items) == 1, f"search failed: {list(app.items)}"
    app.search_query.set('')
    app.toggle_theme()
    app.update()
    app.toggle_details()
    app.update()
    app.search_subfolders.set(True)
    app.refresh()
    for _ in range(30):
        app.update()
        time.sleep(.02)
    app.on_close()
    print('GUI smoke test OK')

"""GUI integration test: requires xvfb-run on Linux, desktop session on Windows."""
import sys
import tempfile
import time
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app import FileHub


def until(app, predicate, secs=6):
    end = time.monotonic() + secs
    while time.monotonic() < end:
        app.update()
        if predicate():
            return
        time.sleep(.03)
    raise AssertionError('GUI action timed out')


class TestGUIActions(unittest.TestCase):
    def test_copy_move_do_not_overwrite(self):
        with tempfile.TemporaryDirectory() as tmp:
            source = Path(tmp) / 'src'
            dest = Path(tmp) / 'dest'
            target = Path(tmp) / 'target'
            source.mkdir(); dest.mkdir(); target.mkdir()
            (source / 'hello.txt').write_text('new', encoding='utf-8')
            (dest / 'hello.txt').write_text('original', encoding='utf-8')
            app = FileHub()
            try:
                app.navigate(str(source))
                until(app, lambda: len(app.items) == 1)
                app.table.selection_set(str(source / 'hello.txt'))
                app.on_copy()
                app.navigate(str(dest))
                app.on_paste()
                until(app, lambda: not app.running_op and (dest / 'hello - bản sao.txt').exists())
                self.assertEqual((dest / 'hello.txt').read_text(), 'original')
                self.assertEqual((dest / 'hello - bản sao.txt').read_text(), 'new')
                until(app, lambda: len(app.items) == 2)
                app.table.selection_set(str(dest / 'hello - bản sao.txt'))
                app.on_cut()
                app.navigate(str(target))
                app.on_paste()
                until(app, lambda: not app.running_op and (target / 'hello - bản sao.txt').exists())
                self.assertFalse((dest / 'hello - bản sao.txt').exists())
            finally:
                app.on_close()


if __name__ == '__main__':
    unittest.main()
